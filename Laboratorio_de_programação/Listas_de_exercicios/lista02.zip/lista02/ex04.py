#4- Faça um programa, utilizando while, que mostre na tela os números de 0 a 100.

contador=0
while contador<101:
    print(contador)
    contador+=1